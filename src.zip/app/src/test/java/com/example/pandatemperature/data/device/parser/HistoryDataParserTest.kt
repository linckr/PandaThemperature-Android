package com.example.pandatemperature.data.device.parser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

class HistoryDataParserTest {

    @Test
    fun parsesEightByteV1RecordWithoutPressureOrVoltage() {
        val packet = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(1_700_000_000)
            .putShort(2534.toShort())
            .putShort(4567.toShort())
            .array()

        val record = HistoryDataParser("AA:BB", HistoryRecordFormat.V1)
            .parse(packet)
            ?.single() ?: error("record missing")

        assertEquals(1_700_000_000L, record.timestamp)
        assertEquals(25.34f, record.temperature, 0.001f)
        assertEquals(45.67f, record.humidity, 0.001f)
        assertNull(record.pressure)
        assertNull(record.batteryVoltage)
    }

    @Test
    fun parsesTwelveByteV2RecordWithoutVoltage() {
        val packet = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(1_700_000_000)
            .putShort(2534.toShort())
            .putShort(4567.toShort())
            .putInt(101325)
            .array()

        val record = HistoryDataParser("AA:BB", HistoryRecordFormat.V2)
            .parse(packet)
            ?.single() ?: error("record missing")

        assertEquals(1013.25f, record.pressure ?: error("pressure missing"), 0.001f)
        assertNull(record.batteryVoltage)
    }

    @Test
    fun parsesFourteenByteV3RecordWithVoltage() {
        val packet = ByteBuffer.allocate(14).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(1_700_000_000)
            .putShort(2534.toShort())
            .putShort(4567.toShort())
            .putInt(101325)
            .putShort(2900.toShort())
            .array()

        val record = HistoryDataParser("AA:BB", HistoryRecordFormat.V3)
            .parse(packet)
            ?.single() ?: error("record missing")

        assertEquals(2.9f, record.batteryVoltage ?: error("voltage missing"), 0.001f)
    }
}
